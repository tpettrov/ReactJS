/**
 * Created by apetrov on 7/11/2017.
 */
import React, {Component} from 'react'


class ListPagePets extends Component {

    render() {


        return (

            <h1> List Pets Page</h1>


        )

    }


}

export default ListPagePets