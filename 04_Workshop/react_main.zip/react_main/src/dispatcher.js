/**
 * Created by apetrov on 7/11/2017.
 */
import { Dispatcher } from 'flux'

export default new Dispatcher()