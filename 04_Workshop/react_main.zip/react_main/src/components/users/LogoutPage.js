/**
 * Created by Toni on 7/11/2017.
 */
import {Component} from 'react'
import Auth from './Auth'


class LogoutPage extends Component {


    componentWillMount(){

        Auth.deauthenticateUser()
        Auth.removeUser()
        this.props.history.push('/users/login')

    }

    render() {

        return null






    }







}