/**
 * Created by Toni on 7/5/2017.
 */
import { Dispatcher } from 'flux'

export default new Dispatcher()
