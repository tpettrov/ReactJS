import {EventEmitter} from 'events'
import dispatcher from '../dispatcher'

class UserStore extends EventEmitter {


    registerUser(user) {

      console.log('tuk')
       
        
    }

   
    handleActionUsers (action) {

        switch (action.type) {
            
            case 'REGISTER_USER': {
                this.registerUser(action.data)
                break
            }
           
            default: break
        }
    }


}

let userStore = new UserStore()

dispatcher.register(userStore.handleActionUsers.bind(userStore))


export default userStore